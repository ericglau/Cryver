package com.codebind;

public class App {
	public String Sample() {
		return "sample";
	}

}
